import "./NewExpense.css";
import ExpenseFrom from "./ExpenseForm";

const NewExpense = (props) => {
  const saveExanseDateHandler = (enteredExpenseData) => {
    const expenseData = {
      ...enteredExpenseData,
      id: Math.random().toString(),
    };
    props.onAddExpense(expenseData);
  };
  return (
    <div className="new-expense">
      <ExpenseFrom onSaveExpense={saveExanseDateHandler} />
    </div>
  );
};

export default NewExpense;
